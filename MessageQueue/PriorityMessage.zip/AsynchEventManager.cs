using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Configuration;
using ExtensionFunctions;

namespace ObjectEventQueue
{
    public delegate void ObjectEventDelegate(object messagePayload);

    public class AsynchEventManager //: IDisposable
    {
        private static AsynchEventManager _instance = null;

        private Dictionary<string, List<ListenInfoBase>> _listenerMap = new Dictionary<string, List<ListenInfoBase>>();

        private List<MessageBase> _messageQueue = new List<MessageBase>();

        AutoResetEvent _stopEvent = new AutoResetEvent(false);
        //private List<ObjectEventBase> _eventQueue = new List<ObjectEventBase>();

        // A semaphore for the worker thread pool
        //
        private static Semaphore _pool;

        // 
        private Mutex _listenerMapMutex = new Mutex();
        private Mutex _priorityQueueMutex = new Mutex();

        private AsynchEventManager()
        {
            // Create a semaphore that can satisfy up to three
            // concurrent requests. Use an initial count of zero,
            // so that the entire semaphore count is initially
            // owned by the main program thread.
            //
            int maxWorkers = 5;

            if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["MaxWorkerThreads"]))
            {
                int.TryParse(ConfigurationManager.AppSettings["MaxWorkerThreads"], out maxWorkers);
            }

            _pool = new Semaphore(0, maxWorkers );

            StartPump();
        }

        public static AsynchEventManager Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new AsynchEventManager();
                }

                return _instance;
            }
        }

        public void Subscribe(ObjectEventDelegate eventToCall, Type messagePayloadType)
        {
            string messageKey = messagePayloadType.ToString();
            //PriorityMessage<T> eventToListen = new PriorityMessage<T>(eventName);

            ListenInfoBase listenerInfo = new ListenInfoBase()
            {
                EventDelegate = eventToCall
            };

            //{
            //    EventDelegate = eventToCall
            //};

            //EventInfo newEntry = new EventInfo();
            //newEntry.EventDelegate = eventToCall;
            //newEntry.EventKey = eventKey;

            //List<EventInfo> eventInfoList;

            if (_listenerMapMutex.WaitOne())
            {
                try
                {
                    if (!_listenerMap.ContainsKey(messageKey))
                    {
                        _listenerMap[messageKey] = new List<ListenInfoBase>();
                    }

                    //if (!_events.TryGetValue(eventName, out eventInfoList))
                    //{
                    //    _events[eventName] = new List<EventInfo>();
                    //}

                    _listenerMap[messageKey].Add(listenerInfo);
                }
                catch (Exception ex)
                {
                }
                finally
                {
                    _listenerMapMutex.ReleaseMutex();
                }
            }
        }

        public void Publish(object messagePayload, int priority, DateTime sendTime, Type payloadType)
        {
            MessageBase eventToSend = new MessageBase()
            {
                Priority = priority,
                SendTime = sendTime,
                Payload = messagePayload,
                PayloadType = payloadType
            };

            ListenInfoBase[] listeners = GetListeners(payloadType.ToString());
            if (listeners != null)
            {
                InvokeEvent(eventToSend, listeners);
            }

            //QueueEvent(eventToSend, priority);


            // TODO: Change to new "worker" slot approach
            // code to change here:
            // add event to an outbound queue
            // have a separate thread only pick up MAX_WORKERS
            // call beginInvoke only on active items

            // TODO: Move this code into the message pump
            // after the semaphore wait succeeds
            //MessageBase msg = DequeueEvent();

            //if( msg != null  )
            //{
            //    ListenInfoBase[] listeners = GetListeners(msg.PayloadType.ToString());
            //    if (listeners != null)
            //    {
            //        InvokeEvent(msg, listeners);
            //    }

            //}

            // finally decrement semaphore count to release our resources

            //InvokeEvent(eventToSend);
        }

        private void MessagePumpThread()
        {
            _started = true;
            while (!_stopEvent.WaitOne(1))
            {
                MessageBase message = DequeueEvent();

                if (message != null)
                {
                    if (_listenerMapMutex.WaitOne())
                    {
                        try
                        {
                            if (_listenerMap.ContainsKey(message.PayloadType.ToString()))
                            {
                                foreach (ListenInfoBase eventInfo in _listenerMap[message.PayloadType.ToString()])
                                {
                                    ObjectEventDelegate callback = eventInfo.EventDelegate;
                                    if (callback != null)
                                    {
                                        callback.BeginInvoke(
                                            message.Payload,
                                            (ar) =>
                                            {
                                                try
                                                {
                                                    ObjectEventDelegate cb = ar.AsyncState as ObjectEventDelegate;
                                                    cb.EndInvoke(ar);
                                                }
                                                catch (Exception ex)
                                                {
                                                }
                                            },
                                            callback);
                                    }
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                        }
                        finally
                        {
                            _listenerMapMutex.ReleaseMutex();
                        }
                    }

                    //ListenInfoBase[] listeners = GetListeners(message.PayloadType.ToString());

                    //if (listeners != null)
                    //{

                    //    InvokeEvent(message, listeners);
                    //}
                }
            }
            _started = false;
        }

        private void QueueEvent(MessageBase eventToSend, int priority)
        {
            if (_priorityQueueMutex.WaitOne())
            {
                try
                {
                    _messageQueue.Add(eventToSend);
                }
                catch (Exception ex)
                {
                }
                finally
                {
                    _priorityQueueMutex.ReleaseMutex();
                }
            }
        }

        private MessageBase DequeueEvent()
        {
            MessageBase msg = null;

            if (_priorityQueueMutex.WaitOne())
            {
                try
                {
                    if (_messageQueue.Count > 0)
                    {
                        msg = _messageQueue[0];
                        _messageQueue.RemoveAt(0);
                    }
                }
                catch (Exception ex)
                {
                }
                finally
                {
                    _priorityQueueMutex.ReleaseMutex();
                }
            }

            return msg;
        }

        private ListenInfoBase [] GetListeners(string eventType)
        {
            ListenInfoBase [] listeners = null;
            if (_listenerMapMutex.WaitOne())
            {
                try
                {
                    if (_listenerMap.ContainsKey(eventType))
                    {
                        listeners = _listenerMap[eventType].ToArray();
                    }
                }
                catch (Exception ex)
                {
                }
                finally
                {
                    _listenerMapMutex.ReleaseMutex();
                }
            }
            return listeners;
        }

        private void MessageEventHandler(MessageBase msg, ListenInfoBase[] listeners)
        {
            foreach (ListenInfoBase eventInfo in listeners)
            {
                ObjectEventDelegate callback = eventInfo.EventDelegate;
                if (callback != null)
                {
                    callback.Invoke(msg.Payload);
                }

            //    if (callback != null)
            //    {
            //        callback.BeginInvoke(msg.EventName,
            //            msg.Message,
            //            (ar) =>
            //            {
            //                try
            //                {
            //                    ObjectEventDelegate<T> cb = ar.AsyncState as ObjectEventDelegate<T>;
            //                    cb.EndInvoke(ar);
            //                }
            //                catch (Exception ex)
            //                {
            //                }
            //            },
            //            callback);
            //    }
            }
        }


        private void InvokeEvent(MessageBase msg, ListenInfoBase[] listeners)
        {
            foreach (ListenInfoBase eventInfo in listeners)
            {
                ObjectEventDelegate callback = eventInfo.EventDelegate;
                if (callback != null)
                {
                    callback.BeginInvoke(
                        msg.Payload,
                        (ar) =>
                        {
                            try
                            {
                                ObjectEventDelegate cb = ar.AsyncState as ObjectEventDelegate;
                                cb.EndInvoke(ar);
                            }
                            catch (Exception ex)
                            {
                            }
                        },
                        callback);
                }
            }

            ////List<EventInfo> eventInfoList;
            //if (_listenerMapMutex.WaitOne())
            //{
            //    try
            //    {
            //        if (_listenerMap.ContainsKey(messageToSend.EventName))
            //        {
            //            foreach (ListenInfoBase eventInfo in _listenerMap[messageToSend.EventName])
            //            {
            //                //eventBase.TriggerEvent(eventInfo.EventDelegate);
            //                //TODO: Remove TriggerEvent from eventBase, remove eventBase
            //                // switch to AsynchObjectEvent<T>
            //                // switch InvokeEvent to InvokeEvent<T>

            //                ObjectEventDelegate<T> callback = eventInfo.EventDelegate as ObjectEventDelegate<T>;
            //                if (callback != null)
            //                {
            //                    callback.BeginInvoke(messageToSend.EventName,
            //                        messageToSend.Message,
            //                        (ar) =>
            //                        {
            //                            try
            //                            {
            //                                // release the semaphore here

            //                                ObjectEventDelegate<T> cb = ar.AsyncState as ObjectEventDelegate<T>;
            //                                cb.EndInvoke(ar);
            //                            }
            //                            catch (Exception ex)
            //                            {
            //                            }
            //                        },
            //                        callback);
            //                }
            //            }
            //        }
            //    }
            //    catch (Exception ex)
            //    {
            //    }
            //    finally
            //    {
            //        _listenerMapMutex.ReleaseMutex();
            //    }
            //}
        }

        private bool _started = false;
        public void StartPump()
        {
            if (!_started)
            {
                Thread thread = new Thread(new ThreadStart(MessagePumpThread));
                thread.Start();
            }
        }

        public void StopPump()
        {
            _stopEvent.Set();
        }

    }
}
