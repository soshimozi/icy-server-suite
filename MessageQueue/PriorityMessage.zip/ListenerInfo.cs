﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ObjectEventQueue
{
    //class ListenerInfo<T> : ListenInfoBase
    //{
    //    public ObjectEventDelegate<T> EventDelegate
    //    {
    //        get;
    //        set;
    //    }
    //}
}
