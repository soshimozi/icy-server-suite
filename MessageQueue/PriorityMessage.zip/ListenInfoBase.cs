﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ObjectEventQueue
{
    class ListenInfoBase
    {
        public ObjectEventDelegate EventDelegate
        {
            get;
            set;
        }
    }
}
