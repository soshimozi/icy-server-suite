using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace ObjectEventQueue
{
    public delegate void ObjectEventDelegate<T>(string eventName, T messagePayload);

    public class AsynchEventManager
    {
        private Dictionary<string, List<EventInfo>> _events = new Dictionary<string, List<EventInfo>>();
        private List<ObjectEventBase> _eventQueue = new List<ObjectEventBase>();

        private static AsynchEventManager _instance = null;

        // A semaphore for the worker thread pool
        //
        private static Semaphore _pool;

        // 
        private Mutex _queueMutex = new Mutex();

        private AsynchEventManager()
        {
            // Create a semaphore that can satisfy up to three
            // concurrent requests. Use an initial count of zero,
            // so that the entire semaphore count is initially
            // owned by the main program thread.
            //
            _pool = new Semaphore(0, 3);

        }

        public static AsynchEventManager Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new AsynchEventManager();
                }

                return _instance;
            }
        }

        public void Subscribe<T>(ObjectEventDelegate<T> eventToCall, object eventKey)
        {
            string eventName = typeof(T).ToString();
            AsynchObjectEvent<T> eventToListen = new AsynchObjectEvent<T>(eventName);

            EventInfo newEntry = new EventInfo();
            newEntry.EventDelegate = eventToCall;
            newEntry.EventKey = eventKey;

            List<EventInfo> eventInfoList;

            if (_queueMutex.WaitOne())
            {
                if (!_events.TryGetValue(eventName, out eventInfoList))
                {
                    _events[eventName] = new List<EventInfo>();
                }

                _events[eventName].Add(newEntry);
                _queueMutex.ReleaseMutex();
            }
        }

        public void Publish<T>(T message)
        {
            AsynchObjectEvent<T> eventToSend = new AsynchObjectEvent<T>(typeof(T).ToString());
            eventToSend.Value = message;

            // TODO: Change to new "worker" slot approach
            // code to change here:
            // add event to an outbound queue
            // have a separate thread only pick up MAX_WORKERS
            // call beginInvoke only on active items
            InvokeEvent(eventToSend);
        }

        private void InvokeEvent(/*AsynchObjectEvent*/ ObjectEventBase eventBase)
        {
            List<EventInfo> eventInfoList;
            if (_events.TryGetValue(eventBase.EventName, out eventInfoList))
            {
                foreach (EventInfo eventInfo in eventInfoList)
                {
                    eventBase.TriggerEvent(eventInfo.EventDelegate);
                    //TODO: Remove TriggerEvent from eventBase, remove eventBase
                    // switch to AsynchObjectEvent<T>
                    // switch InvokeEvent to InvokeEvent<T>

                    //ObjectEventDelegate<T> callback = eventInfo.EventDelegate as ObjectEventDelegate<T>;
                    //if (callback != null)
                    //{
                    //    callback.BeginInvoke(eventBase.EventName,
                    //        eventBase.Value,
                    //        (ar) =>
                    //        {
                    //            try
                    //            {
                    //                ObjectEventDelegate<T> cb = ar.AsyncState as ObjectEventDelegate<T>;
                    //                cb.EndInvoke(ar);
                    //            }
                    //            catch (Exception ex)
                    //            {
                    //            }
                    //        },
                    //        callback);
                    //}
                }
            }
        }
    }
}
