using System;
using System.Collections.Generic;
using System.Text;

namespace MessageQueue
{
    //public enum ServerEvents
    //{
    //    Connect,
    //    ServerData,
    //    ClientData,
    //    ServerDisconnect,
    //    ClientDisconnect
    //}
}
